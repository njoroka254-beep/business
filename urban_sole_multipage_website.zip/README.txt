URBAN SOLE MULTI-PAGE WEBSITE

Files:
- index.html = Home
- men.html = Men's footwear
- women.html = Women's footwear
- kids.html = Kids collection
- sandals.html = Sandals collection
- sneakers.html = Sneakers & sports shoes
- contact.html = Contact / ordering
- styles.css = Shared design
- images/ = Your supplied product images

HOW TO USE:
1. Extract the ZIP.
2. Upload all files/folders while preserving the structure.
3. Set index.html as the homepage if your hosting asks for a default page.
4. The WhatsApp buttons use 0745 150424.

IMPORTANT:
The website is static HTML/CSS. You can host it on most static hosting services or normal web hosting.
